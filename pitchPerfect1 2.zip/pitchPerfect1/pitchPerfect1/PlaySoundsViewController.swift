//
//  PlaySoundsViewController.swift
//  pitchPerfect1
//
//  Created by Josh on 2/25/16.
//  Copyright © 2016 Foomon Inc. All rights reserved.
//

import UIKit
import AVFoundation

class PlaySoundsViewController: UIViewController {
    
    //how to create an instance of avaudioplayer
    var audioPlayer:AVAudioPlayer!
    var receivedAudio:RecordedAudio!
    var audioEngine:AVAudioEngine!
    var audioFile:AVAudioFile!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        audioPlayer = try! AVAudioPlayer(contentsOfURL: receivedAudio.filePathUrl)
        audioPlayer.enableRate = true
        
        audioEngine = AVAudioEngine()
        audioFile = try! AVAudioFile(forReading: receivedAudio.filePathUrl)

    }
    
    func stopAndResetAudioPlayback() {
        
        audioEngine.stop()
        audioEngine.reset()
        audioPlayer.stop()
        
    }
    
    func playAudioWithVariableRate(rate: Float) {
        
        stopAndResetAudioPlayback()
        audioPlayer.rate = rate
        audioPlayer.currentTime = 0.0
        audioPlayer.play()
        
    }
    
    
    @IBAction func slowAudio(sender: UIButton) {
        
        playAudioWithVariableRate(0.5)
    }
    
    @IBAction func fastAudio(sender: UIButton) {
        
        playAudioWithVariableRate(2.0)
    }
    
    func playAudioWithVariablePitch(pitch: Float) {
        
        stopAndResetAudioPlayback()
        
        var audioPlayerNode = AVAudioPlayerNode()
        audioEngine.attachNode(audioPlayerNode)
        
        var changePitchEffect = AVAudioUnitTimePitch()
        changePitchEffect.pitch = pitch
        audioEngine.attachNode(changePitchEffect)
        
        audioEngine.connect(audioPlayerNode, to: changePitchEffect, format: nil)
        audioEngine.connect(changePitchEffect, to: audioEngine.outputNode, format: nil)
       
        audioPlayerNode.scheduleFile(audioFile, atTime: nil, completionHandler: nil)
        
        try! audioEngine.start()
        
        audioPlayerNode.play()
        
    }
    
    @IBAction func chipmunkAudio(sender: UIButton) {
        playAudioWithVariablePitch(1000)
    }
    
    @IBAction func vaderAudio(sender: UIButton) {
        playAudioWithVariablePitch(-1000)
    }
    
    
    @IBAction func stopAudio(sender: UIButton) {
        stopAndResetAudioPlayback()
    }
    
}
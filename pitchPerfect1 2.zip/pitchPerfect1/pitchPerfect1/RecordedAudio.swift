//
//  RecordedAudio.swift
//  pitchPerfect1
//
//  Created by Josh on 2/26/16.
//  Copyright © 2016 Foomon Inc. All rights reserved.
//

import Foundation

class RecordedAudio{
    
    var filePathUrl: NSURL
    var title: String!
    
    init(url: NSURL){
        filePathUrl = url
        title = url.lastPathComponent
    }
    
}